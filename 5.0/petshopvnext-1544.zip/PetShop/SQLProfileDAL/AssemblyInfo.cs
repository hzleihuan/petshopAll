using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

[assembly: CLSCompliant(true)]
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: ComVisible(false)]
[assembly: ReliabilityContract(Consistency.WillNotCorruptState, Cer.MayFail)]

[assembly: AssemblyTitle(".NET Pet Shop Sql Server Profile DAL Implementaion")]
[assembly: AssemblyDescription(".NET Pet Shop DAL Components")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct(".NET Pet Shop 4.0")]
[assembly: AssemblyCopyright("Copyright � 2005 Microsoft Corporation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]