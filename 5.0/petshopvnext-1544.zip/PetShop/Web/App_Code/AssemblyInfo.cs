using System.Reflection;
using System;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("4.0.4.50")]
[assembly: ComVisible(false)]

[assembly: AssemblyTitle(".NET Pet Shop Web")]
[assembly: AssemblyDescription(".NET Pet Shop Web Components")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct(".NET Pet Shop 4.0")]
[assembly: AssemblyCopyright("Copyright � 2005 Microsoft Corporation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]